import React from "react";
import "./styles.css";
import AppBar from "./components/AppBar";
import Layout from "./components/Layout";
import ROUTES, { RenderRoutes } from "./routes";
import { ProvideAuth } from "./use-auth";

export default function App() {
  return (
    <ProvideAuth>
      <div className="App">
        {/* AppBar menu navigation */}
        <AppBar />
        {/* Content layout */}
        <Layout>
          <RenderRoutes routes={ROUTES} />
        </Layout>
      </div>
    </ProvideAuth>
  );
}
