export function signin(username, password) {
  return new Promise(resolve => {
    setTimeout(() => resolve({ success: true, username }));
  });
}

export function signout() {
  return new Promise(resolve => {
    setTimeout(() => resolve({ success: true }));
  });
}
