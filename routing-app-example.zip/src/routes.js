import React, { lazy, Suspense } from "react";
import { Switch, Route } from "react-router-dom";

const Home = lazy(() => import("./components/Home"));
const About = lazy(() => import("./components/About"));
const Categories = lazy(() => import("./components/Categories"));
const Login = lazy(() => import("./components/Login"));

const ROUTES = [
  { path: "/", key: "ROOT", label: "Home", exact: true, component: Home },
  {
    path: "/about",
    key: "ABOUT",
    label: "About",
    exact: true,
    component: About
  },
  {
    path: "/categories",
    key: "CATEGORIES",
    label: "Categories",
    exact: true,
    component: Categories
  },
  {
    path: "/login",
    key: "LOGIN",
    label: "Login",
    exact: true,
    component: Login
  }
  // { path: "/sign-up", key: "SIGN_UP", exact: true, component: SignUp },
];

export default ROUTES;

/**
 * Render a route with potential sub routes
 * See more here: https://reacttraining.com/react-router/web/example/route-config
 */
function RouteWithSubRoutes({ path, exact, routes, component: Component }) {
  return (
    <Route
      path={path}
      exact={exact}
      render={props => {
        return (
          <Suspense fallback={<span>Loading...</span>}>
            <Component {...props} routes={routes} />
          </Suspense>
        );
      }}
    />
  );
}

/**
 * Use this component for any new section of routes (any config object that has a "routes" property
 */
export function RenderRoutes({ routes }) {
  return (
    <Switch>
      {routes.map(route => {
        return <RouteWithSubRoutes key={route.key} {...route} />;
      })}
      <Route component={() => <h1>Page Not Found!</h1>} />
    </Switch>
  );
}
