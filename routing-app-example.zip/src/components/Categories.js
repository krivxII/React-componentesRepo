import React from "react";
import { useLocation } from "react-router-dom";
import qs from "query-string";

export default function() {
  const { search } = useLocation();
  const parsed = qs.parse(search, { arrayFormat: "index" });
  console.log({ search, parsed });
  return (
    <div className="Categories">
      <h1>Categories page</h1>
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Libero
        corrupti at rem atque culpa odit voluptate ipsum reprehenderit nam
        maxime, ab soluta cum accusantium, iusto esse? Tempora voluptatum ipsa
        ipsam.
      </p>
    </div>
  );
}
