import React, { useState } from "react";
import { Redirect, useHistory } from "react-router-dom";
import { OutlinedInput, Button, FormControl } from "@material-ui/core";
import makeStyles from "@material-ui/core/styles/makeStyles";
import { useAuth } from "../use-auth";

const useStyles = makeStyles({
  loginWrapper: {
    padding: 50
  },
  loginButton: {
    marginTop: 8
  }
});

export default function Login() {
  const [username, updateUsername] = useState("");
  const auth = useAuth();
  const history = useHistory();
  const classes = useStyles();

  // "log in" a user
  function handleLogin() {
    auth.signin(username);
    // localStorage.setItem("user");
    history.push("/");
  }

  // if user already "authenticated", redirect them to the app
  if (auth && auth.user) {
    return <Redirect to="/" />;
  }

  return (
    <div className={classes.loginWrapper}>
      <h1>Log In</h1>
      <FormControl>
        <OutlinedInput
          value={username}
          onChange={e => updateUsername(e.target.value)}
          placeholder="Username"
        />
        <Button
          disabled={!username}
          onClick={handleLogin}
          variant="contained"
          color="primary"
          className={classes.loginButton}
        >
          Log In
        </Button>
      </FormControl>
    </div>
  );
}
