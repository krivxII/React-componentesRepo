import React from "react";
import { Link } from "react-router-dom";
import { AppBar, Toolbar, Menu, MenuItem, IconButton } from "@material-ui/core";
import { AccountCircle } from "@material-ui/icons";
import makeStyles from "@material-ui/core/styles/makeStyles";
import ROUTES from "../routes";
import { useAuth } from "../use-auth";

const useStyles = makeStyles({
  menuItem: {
    margin: "0 8px",
    color: "white",
    textDecoration: "none"
  },
  toolbarWrapper: {
    display: "flex",
    justifyContent: "space-between"
  },
  userText: {
    marginLeft: 8,
    fontSize: "1.2rem"
  },
  navLeft: {},
  navRight: {}
});

export default function() {
  const classes = useStyles();
  const auth = useAuth();
  console.log("appbar", auth);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);

  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

  const handleProfileMenuOpen = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = event => {
    setMobileMoreAnchorEl(event.currentTarget);
  };
  const renderMenu = ({ key, path, label }) => {
    if (["/login", "/sign-up"].includes(path)) {
      return null;
    }
    return (
      <Link key={key} className={classes.menuItem} to={path}>
        {label}
      </Link>
    );
  };
  const menuId = "primary-search-account-menu";
  const renderUserMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      id={menuId}
      keepMounted
      transformOrigin={{ vertical: "top", horizontal: "right" }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
      <MenuItem onClick={() => auth.signout()}>Logout</MenuItem>
    </Menu>
  );
  return (
    <AppBar position="static">
      <Toolbar className={classes.toolbarWrapper}>
        <div className={classes.navLeft}>
          {ROUTES.map(route => renderMenu(route))}
        </div>
        <div className={classes.navRight}>
          {auth && auth.user ? (
            <IconButton
              edge="end"
              aria-label="account of current user"
              aria-controls={menuId}
              aria-haspopup="true"
              onClick={handleProfileMenuOpen}
              color="inherit"
            >
              <AccountCircle className={classes.accountIcon} />
              <span className={classes.userText}>Hi, {auth.user}</span>
            </IconButton>
          ) : (
            <Link key="LOGIN" className={classes.menuItem} to="/login">
              Login
            </Link>
          )}
        </div>
      </Toolbar>
      {renderUserMenu}
    </AppBar>
  );
}
