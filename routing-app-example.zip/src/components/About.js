import React from "react";

export default function() {
  return (
    <div className="About">
      <h1>About page</h1>
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Libero
        corrupti at rem atque culpa odit voluptate ipsum reprehenderit nam
        maxime, ab soluta cum accusantium, iusto esse? Tempora voluptatum ipsa
        ipsam.
      </p>
    </div>
  );
}
